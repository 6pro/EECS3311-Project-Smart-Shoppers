package com.asi.model;

public class Admin extends User{

	public String getRole() {
		return "Admin";
	}
	
	public void setRole() {
		this.role = "Admin";
	}

}
