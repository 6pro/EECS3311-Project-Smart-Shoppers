package com.asi.model;

public class Manager extends User{

	public String getRole() {
		return "Manager";
	}
	public void setRole() {
		this.role = "Manager";
	}

}
