package com.asi.model;

public class Customer extends User{
	
	public String getRole() {
		return "Customer";
	}
	public void setRole() {
		this.role = "Customer";
	}

}
